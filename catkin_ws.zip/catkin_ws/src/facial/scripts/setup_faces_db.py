#!usr/bin/env python3

import sqlite3
import face_recognition

def create_database(db_path="faces.db"):
	conn = sqlite3.connect(db_path)
	cursor = conn.cursor()
	
	cursor.execute("""CREATE TABLE IF NOT EXISTS faces (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	name TEXT NOT NULL,
	encoding TEXT NOT NULL
	)
	""")
	conn.commit()
	conn.close()

def add_face_to_database(name,image_path, db_path = "faces.db"):
	conn = sqlite3.connect(db_path)
	cursor = conn.cursor()
	
	image = face_recognition.load_image_file(image_path)
	encodings = face_recognition.face_encodings(image)
	if encodings:
		encoding_str = ", ".join(map(str,encodings[0]))
		cursor.execute("INSERT INTO faces (name, encoding) VALUES (?, ?)", (name, encoding_str))
	else:
		print(f"Could not find a face in {image_path}")
	conn.close()

create_database()
