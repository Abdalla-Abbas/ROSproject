#!/usr/bin/env python3

from ultralytics import YOLO
import rospy
import cv2
import face_recognition
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge
import numpy as np
import os

# Initialize known face encodings and names
known_face_encodings = []
known_face_names = []

# Directory to store images of faces
face_image_dir = 'saved_faces'
os.makedirs(face_image_dir, exist_ok=True)

# Load known faces (if you have any saved previously)
def load_known_faces():
    global known_face_encodings, known_face_names
    for file_name in os.listdir(face_image_dir):
        if file_name.endswith('.jpg'):
            image = face_recognition.load_image_file(os.path.join(face_image_dir, file_name))
            encoding = face_recognition.face_encodings(image)
            if encoding:
                known_face_encodings.append(encoding[0])
                known_face_names.append(file_name.split('.')[0])  # Name from the file name

load_known_faces()

def process_frame(model, frame):
    # Predict faces using YOLOv8
    results = model.predict(source=frame, conf=0.5)
    detections = results[0].boxes.data.cpu().numpy()

    faces_in_frame = []

    for det in detections:
        x1, y1, x2, y2, conf, cls = det
        face_image = frame[int(y1):int(y2), int(x1):int(x2)]
        
        # Convert face image to RGB for face recognition
        rgb_face = cv2.cvtColor(face_image, cv2.COLOR_BGR2RGB)
        face_encoding = face_recognition.face_encodings(rgb_face)

        if face_encoding:
            matches = face_recognition.compare_faces(known_face_encodings, face_encoding[0])
            name = "Unknown Face"
            
            # If a match is found, get the name of the matched face
            if True in matches:
                first_match_index = matches.index(True)
                name = known_face_names[first_match_index]
            else:
                # Save the new unknown face
                new_name = f"unknown_{len(known_face_encodings) + 1}.jpg"
                cv2.imwrite(os.path.join(face_image_dir, new_name), face_image)
                known_face_encodings.append(face_encoding[0])
                known_face_names.append(new_name.split('.')[0])  # Name from the file name

                # Ask user to input a name for the detected face
                name = input(f"Enter a name for the new face (currently labeled as {new_name}): ")
                
                # Update name and save the image with the provided name
                os.rename(os.path.join(face_image_dir, new_name), os.path.join(face_image_dir, f"{name}.jpg"))
                known_face_names[-1] = name

            # Draw bounding box and name on the image
            cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
            cv2.putText(frame, name, (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
    
    return frame, detections

def callback(data):
    bridge = CvBridge()
    try:
        frame = bridge.imgmsg_to_cv2(data, "bgr8")
        processed_frame, detections = process_frame(model, frame)
        
        # Log detected faces
        for detection in detections:
            rospy.loginfo(f"Detection: {detection}")
        
        # Publish the processed image
        processed_msg = bridge.cv2_to_imgmsg(processed_frame, encoding="bgr8")
        processed_pub.publish(processed_msg)
        
        # Publish detection results
        result_msg = String()
        result_msg.data = str(detections)
        result_pub.publish(result_msg)

    except Exception as e:
        rospy.logerr(f"Error processing frame: {e}")

if __name__ == "__main__":
    rospy.init_node('face_recognition_subscriber', anonymous=True)
    rospy.Subscriber('camera/image_raw', Image, callback)
    
    processed_pub = rospy.Publisher('yolo/processed_image', Image, queue_size=10)
    result_pub = rospy.Publisher('yolo/detections', String, queue_size=10)
    
    model = YOLO("yolov8n.pt")
    
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
