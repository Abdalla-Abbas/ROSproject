#!/usr/bin/env python3

import rospy
from std_msgs.msg import String
import pyttsx3
import threading

class TextToSpeechNode:
    def __init__(self):
        rospy.init_node("text_to_speech_node", anonymous=True)
        rospy.loginfo("Initializing TTS Node...")

        # Initialize pyttsx3 engine
        self.tts_engine = pyttsx3.init()
        self.tts_engine.setProperty('rate', 150)  # Adjust speech rate
        self.tts_engine.setProperty('volume', 1.0)  # Max volume

        self.text_queue = []  # Queue for incoming text
        self.lock = threading.Lock()  # To protect shared resources

        # ROS Subscriber
        rospy.Subscriber("/user_input", String, self.speak_callback)

        # Thread for TTS processing
        self.tts_thread = threading.Thread(target=self.process_queue)
        self.tts_thread.daemon = True  # Daemon thread will close with the main process
        self.tts_thread.start()

        rospy.loginfo("TTS Node initialized. Waiting for input text...")

    def speak_callback(self, msg):
        text = msg.data
        rospy.loginfo(f"Received text: {text}")
        with self.lock:
            self.text_queue.append(text)

    def process_queue(self):
        while not rospy.is_shutdown():
            if self.text_queue:
                with self.lock:
                    text = self.text_queue.pop(0)
                try:
                    rospy.loginfo(f"Speaking: {text}")
                    self.tts_engine.say(text)
                    self.tts_engine.runAndWait()
                except Exception as e:
                    rospy.logerr(f"Error in TTS engine: {e}")

    def run(self):
        rospy.spin()


if __name__ == "__main__":
    try:
        tts_node = TextToSpeechNode()
        tts_node.run()
    except rospy.ROSInterruptException:
        pass
