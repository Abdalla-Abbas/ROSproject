#!/usr/bin/env python3

import rospy
from std_msgs.msg import String
import whisper
import pyaudio
import numpy as np
import wave

# Function to save audio chunks as a WAV file for Whisper
def save_audio_to_wav(audio_buffer, sample_rate, filename="temp.wav"):
    with wave.open(filename, 'wb') as wf:
        wf.setnchannels(1)  # Mono audio
        wf.setsampwidth(2)  # 16-bit audio
        wf.setframerate(sample_rate)
        wf.writeframes(audio_buffer)

def stt_publisher():
    rospy.init_node('stt_publisher', anonymous=True)
    pub = rospy.Publisher("/user_input", String, queue_size=10)

    # Initialize PyAudio for real-time audio input
    p = pyaudio.PyAudio()
    sample_rate = 16000
    chunk_size = 1024

    # Initialize Whisper model
    model = whisper.load_model("tiny")

    # Audio stream configuration
    stream = p.open(format=pyaudio.paInt16,
                    channels=1,
                    rate=sample_rate,
                    input=True,
                    frames_per_buffer=chunk_size)

    rospy.loginfo("Listening to microphone...")

    audio_buffer = b''
    buffer_duration = 3  # Buffer audio for 3 seconds

    try:
        while not rospy.is_shutdown():
            # Collect audio chunks for the buffer duration
            for _ in range(int(sample_rate / chunk_size * buffer_duration)):
                data = stream.read(chunk_size, exception_on_overflow=False)
                audio_buffer += data

            # Save the audio buffer to a WAV file
            save_audio_to_wav(audio_buffer, sample_rate)

            # Transcribe the audio using Whisper
            result = model.transcribe("temp.wav", language="en",fp16=False)
            recognized_text = result['text']

            # Publish recognized text to a ROS topic
            pub.publish(recognized_text)
            rospy.loginfo(f"Transcribed Text: {recognized_text}")

            # Clear the buffer for the next batch
            audio_buffer = b''

    except rospy.ROSInterruptException:
        pass
    finally:
        stream.stop_stream()
        stream.close()
        p.terminate()

if __name__ == '__main__':
    try:
        stt_publisher()
    except rospy.ROSInterruptException:
        pass
